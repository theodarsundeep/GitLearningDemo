#####   Properties setting the environment
#####   Properties setting the Entaly platform variables
export dice_home_directory=/dice/platform/demo
export yarn_job_master=yarn-cluster
export table_name_prefix=dice_

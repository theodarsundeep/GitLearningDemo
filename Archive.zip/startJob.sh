#!/bin/bash

#####################################################################################################
#                                                                                                   #
#   This script can be used to start the spark Jobs required for the Entaly platform                #
#   Jobs can be started in yarn-cluster OR yarn-client mode ONLY                                    #
#                                                                                                   #
#####################################################################################################

. setEnvJobs.sh

process_name=$1
yarn_queue_name=$2
release_version=$3

log_level=info
driver_memory=512m
executor_memory=512m

usage=" Syntax to run: ./startJob.sh <Process_name> <yarn_queue_name> <release_version>
        Sample:
        ./startJob.sh processManagerProcess processManagerProcess 1.0.17"

if [ -z "$1" ]
  then
    echo "Please supply the process name"
    echo "$usage"
    exit
fi

if [ -z "$2" ]
  then
    echo "Please supply the yarn queue name"
    echo "$usage"
    exit
fi

if [ -z "$3" ]
  then
    echo "Please supply the release version of the build"
    echo "$usage"
    exit
fi

# check if the PID file exists, If exists process might be already running. Quit from starting again.
if [ -e $dice_home_directory/process/$process_name.pid ]
then
echo "There is a PID file with process id: "
cat $dice_home_directory/process/$process_name.pid
echo "Please check if the process is running with above ID
        If yes, kill the process and remove the PID file
        Else, remove the PID file and submit the job again"
exit
fi

# Block for starting dataProducer Job
function startDataPacketProducer {
spark-submit --master $yarn_job_master --queue $yarn_queue_name --class io.dice.platform.dpkproducer.DPMain --driver-memory $driver_memory --executor-memory $executor_memory --jars /usr/hdp/current/hbase-client/lib/hbase-common.jar,/usr/hdp/current/hbase-client/lib/hbase-client.jar,/usr/hdp/current/hbase-client/lib/hbase-server.jar,/usr/hdp/current/hbase-client/lib/hbase-protocol.jar,/usr/hdp/current/hbase-client/lib/htrace-core-3.1.0-incubating.jar,/usr/hdp/current/hive-client/lib/datanucleus-api-jdo-4.2.1.jar,/usr/hdp/current/hive-client/lib/datanucleus-rdbms-4.1.7.jar,/usr/hdp/current/hive-client/lib/datanucleus-core-4.1.6.jar,/usr/hdp/current/spark-client/lib/spark-hdp-assembly.jar --files $dice_home_directory/propertyFiles/api.properties#api.properties,$dice_home_directory/propertyFiles/dpkproducer.properties#dpkproducer.properties --conf spark.executor.extraJavaOptions="-Dconfig.resource=dpkproducer.properties -Dconfig.resource=api.properties" --conf spark.driver.extraJavaOptions="-Dconfig.resource=dpkproducer.properties -Dconfig.resource=api.properties" $dice_home_directory/DataPacket-Producer-assembly-$release_version-SNAPSHOT.jar > $dice_home_directory/output/$process_name.out 2>&1 &
echo $! > $dice_home_directory/process/$process_name.pid
echo "$process_name job submitted to yarn queue: $yarn_queue_name. It must go to Running state in a while
        If process doesn't start Please check the log file: $dice_home_directory/output/$process_name.out"
}

# Block for starting the process manger and all required processes for the implementation
function startProcess {
spark-submit --master $yarn_job_master --queue $yarn_queue_name --class com.reni.scmplatform.processengine.PEMain --driver-memory $driver_memory --executor-memory $executor_memory --jars /usr/hdp/current/hbase-client/lib/hbase-common.jar,/usr/hdp/current/hbase-client/lib/hbase-client.jar,/usr/hdp/current/hbase-client/lib/hbase-server.jar,/usr/hdp/current/hbase-client/lib/hbase-protocol.jar,/usr/hdp/current/hbase-client/lib/htrace-core-3.1.0-incubating.jar,/usr/hdp/current/hive-client/lib/datanucleus-api-jdo-4.2.1.jar,/usr/hdp/current/hive-client/lib/datanucleus-rdbms-4.1.7.jar,/usr/hdp/current/hive-client/lib/datanucleus-core-4.1.6.jar,/usr/hdp/current/spark-client/lib/spark-hdp-assembly.jar --files /etc/spark/conf/hbase-site.xml,/etc/spark/conf/hive-site.xml $dice_home_directory/SCMPlatformPEFramework-assembly-$release_version-SNAPSHOT.jar --platform.framework.processtype=$process_name platform.framework.logging.level=$log_level > $dice_home_directory/output/$process_name.out 2>&1 &
echo $! > $dice_home_directory/process/$process_name.pid
echo "$process_name job submitted to yarn queue: $yarn_queue_name. It must go to Running state in a while
        If process doesn't start Please check the log file: $dice_home_directory/output/$process_name.out"
}

# Block for starting dataSource Job
function startDataIngestion {
spark-submit --master $yarn_job_master --queue $yarn_queue_name --class io.dice.platform.dataingest.datasources.DataSourceSparkJob --driver-memory $driver_memory --executor-memory $executor_memory --jars /usr/hdp/current/hbase-client/lib/hbase-common.jar,/usr/hdp/current/hbase-client/lib/hbase-client.jar,/usr/hdp/current/hbase-client/lib/hbase-server.jar,/usr/hdp/current/hbase-client/lib/hbase-protocol.jar,/usr/hdp/current/hbase-client/lib/htrace-core-3.1.0-incubating.jar,/usr/hdp/current/hive-client/lib/datanucleus-api-jdo-4.2.1.jar,/usr/hdp/current/hive-client/lib/datanucleus-rdbms-4.1.7.jar,/usr/hdp/current/hive-client/lib/datanucleus-core-4.1.6.jar --files $dice_home_directory/propertyFiles/api.properties#api.properties,$dice_home_directory/propertyFiles/dataingestion.properties#dataingestion.properties --conf spark.executor.extraJavaOptions="-Dconfig.resource=dataingestion.properties -Dconfig.resource=api.properties" --conf spark.driver.extraJavaOptions="-Dconfig.resource=dataingestion.properties -Dconfig.resource=api.properties"  $dice_home_directory/DataIngestion-assembly-$release_version-SNAPSHOT.jar > $dice_home_directory/output/$process_name.out 2>&1 &
echo $! > $dice_home_directory/process/$process_name.pid
echo "$process_name job submitted to yarn queue: $yarn_queue_name. It must go to Running state in a while
        If process doesn't start Please check the log file: $dice_home_directory/output/$process_name.out"
}

if [ $yarn_job_master == yarn-cluster ] || [ $yarn_job_master == yarn-client ]
then

case "$1" in
        dataPacketProducer)
        startDataPacketProducer
        ;;

        dataIngestion)
        startDataIngestion
        ;;

        *)
        startProcess
        ;;

esac

else
echo "This script supports yarn-client and yarn-cluster ONLY. Received \"$yarn_job_master\" as the yarn_job_master please check your settings in setEnv.sh"

fi

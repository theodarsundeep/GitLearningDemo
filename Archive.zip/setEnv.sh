#####   Properties setting the environment
export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.161-0.b14.el7_4.x86_64/jre
export PATH=$JAVA_HOME/bin:$PATH$
export SPARK_HOME=/usr/hdp/current/spark-client
export PATH=$PATH$:$SPARK_HOME/bin:
export SCALA_HOME=/usr/local/scala
export PATH=$PATH$:$SCALA_HOME/bin:
export CLASSPATH=.:$SCALA_HOME/lib:
export HADOOP_HOME=/usr/hdp/current/hadoop-client
export PATH=$HADOOP_HOME/bin:$PATH$
export CLASSPATH=$HADOOP_HOME/etc/hadoop:$CLASSPATH$
export HBASE_HOME=/usr/hdp/current/hbase-client

#####   Properties setting the Entaly platform variables
export dice_home_directory=/dice/platform/demo
export CLASSPATH=$dice_home_directory/Platform-API-assembly-0.1-SNAPSHOT.jar:/usr/hdp/current/hbase-client/lib/hbase-common-1.2.3.jar:/usr/hdp/current/hbase-client/lib/hbase-client-1.2.3.jar:/usr/hdp/current/hbase-client/lib/hbase-server-1.2.3.jar:/usr/hdp/current/hbase-client/lib/hbase-protocol-1.2.3.jar:/usr/hdp/current/hbase-client/lib/guava-12.0.1.jar:/usr/hdp/current/hbase-client/lib/htrace-core-3.1.0-incubating.jar:/usr/hdp/current/hbase-client/lib/hbase-common.jar:/usr/hdp/current/hbase-client/lib/hbase-client.jar:/usr/hdp/current/hbase-client/lib/hbase-server.jar:/usr/hdp/current/hbase-client/lib/hbase-protocol.jar:/usr/hdp/current/hbase-client/lib/guava-12.0.1.jar:/usr/hdp/current/hbase-client/lib/htrace-core-3.1.0-incubating.jar:/usr/hdp/current/hive-client/lib/datanucleus-api-jdo-3.2.6.jar:/usr/hdp/current/hive-client/lib/datanucleus-core-3.2.10.jar:/usr/hdp/current/hive-client/lib/datanucleus-rdbms-3.2.9.jar:/usr/hdp/current/spark-client/lib/spark-hdp-assembly.jar:$CLASSPATH
export yarn_job_master=yarn-cluster
export table_name_prefix=dice_

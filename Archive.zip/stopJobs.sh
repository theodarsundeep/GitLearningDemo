#!/bin/bash

#####################################################################################################
#                                                                                                   #
#   This script can be used to stop the spark Jobs which are registered in Entaly platform          #
#   After stopping the Jobs, this will clear checkpoint, Streaming and spark history directories    #
#                                                                                                   #
#####################################################################################################


. setEnvJobs.sh
. platform_build.properties

processes=$@
searchDirectory=$dice_home_directory/process
logOutputDirectory=$dice_home_directory/output

usage=" Syntax to run: . stopJob.sh <Process_name_1> <Process_name_2> <Process_name_3> . . . . <Process_name_n>
        Sample:
        . stopJob.sh processManagerProcess SeasonPassProcess"

if [ $# -eq 0 ]
  then
    echo "Please supply the process name or process names to be stopped"
    echo "$usage"
    exit
fi

# Function finds out yarn mode set for the cluster.
# If it is yarn-client, it will kill the PID. If it is yarn-cluster, it will use yarn kill
function kill_spark_job {

case "$yarn_job_master" in
        yarn-client)
        pkill -F $searchDirectory/$process_name.pid
        pid_no=$(<$searchDirectory/$process_name.pid)
        echo "Process $process_name running with PID: $pid_no is killed. Please remove the checkpoint directories and spark-history logs"
        rm -f $searchDirectory/$process_name.pid
        ;;

        yarn-cluster)
        yarn application -kill $yarn_application_id
        echo "Killed yarn application with ID: $yarn_application_id"
        rm -f $searchDirectory/$process_name.pid
        ;;

        *)
        echo "This script supports yarn-client and yarn-cluster ONLY. Received \"$yarn_job_master\" as the yarn master please check your settings"
        break
        echo "after break printing message"
        ;;
esac
}

  for process_name in $processes
  do
        if [ -e $searchDirectory/$process_name.pid ]
        then
# Find the yarn application ID from the command line output which is redirected to log file
        yarn_application_id=$(grep YarnClientImpl $logOutputDirectory/$process_name.out | awk '{print $NF}')
        if [ -z $yarn_application_id ]
        then
        echo "Didn't find any Yarn application ID. Nothing to do, exiting the program"
        exit
        fi
        kill_spark_job

            if [ $process_name == dataPacketProducer ]
            then
            hdfs dfs -rm -r -skipTrash $dice_dpk_producer_checkpoint_dir/*
            echo "Removed checkpoint and streaming directories for $process_name"
            echo "Below Spark logs will be removed:"
            hdfs dfs -rm -r -skipTrash /spark-history/$yarn_application_id*

            elif [ $process_name == dataSource ]
            then
            echo "Nothing to clear for dataSource"

            else
            hdfs dfs -rm -r -skipTrash $platform_framework_checkpoint_dir/$process_name/*
            hdfs dfs -rm -r -skipTrash $platform_framework_hdfs_source_data_path/$process_name/*
            echo "Removed checkpoint and streaming directories for $process_name"
            echo "Below Spark logs will be removed:"
            hdfs dfs -rm -r -skipTrash /spark-history/$yarn_application_id*
            fi

        else
        echo "process name: $process_name doesn't have any registered PIDs. If the application is in ACCEPTED state, please use yarn kill <app_id> OR check the name of the process, it is case sensitive"
        fi
  done

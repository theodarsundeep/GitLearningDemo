package com.vriddhi.apps.Entites;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvCustomBindByName;
import com.opencsv.bean.CsvCustomBindByPosition;
import com.opencsv.bean.CsvDate;
import com.vriddhi.apps.Utils.LocalDateConverter;

import java.time.LocalDate;
import java.util.Date;

public class BuySellCalls {
    //Symbol,Trade,Month,Year,Date,Price,Ex. date,Ex. Price,% chg,Profit,% Profit,Shares,Position value,Cum. Profit,# bars,Profit/bar,MAE,MFE,Scale In/Out

    @CsvBindByName(column = "Symbol")
    private String Symbol;
    @CsvBindByName(column = "Trade")
    private String Trade;
    @CsvBindByName(column = "Month")
    private String Month;
    @CsvBindByName(column = "Year")
    private String Year;

    @CsvCustomBindByName(column = "Date",converter = LocalDateConverter.class)
    private Date Date;
    @CsvBindByName(column = "Price")
    private Double Price;
    @CsvBindByName(column = "Ex. date")
    private String ExDate;
    @CsvBindByName(column = "Ex. Price")
    private Double ExPrice;
    @CsvBindByName(column = "% chg")
    private String PercentageChange;
    @CsvBindByName(column = "Profit")
    private String Profit;
    @CsvBindByName(column = "% Profit")
    private String PercentageProfit;
    @CsvBindByName(column = "Shares")
    private String Shares;
    @CsvBindByName(column = "Position value")
    private String PositionValue;
    @CsvBindByName(column = "Cum. Profit")
    private String CumProfit;
    @CsvBindByName(column = "# bars")
    private String NoOfBars;
    @CsvBindByName(column = "Profit/bar")
    private String ProfitBar;
    @CsvBindByName(column = "MAE")
    private String MAE;
    @CsvBindByName(column = "MFE")
    private String MFE;
    @CsvBindByName(column = "Scale In/Out")
    private String ScaleInOut;

    public String getSymbol() {
        return Symbol;
    }

    public void setSymbol(String symbol) {
        Symbol = symbol;
    }

    public String getTrade() {
        return Trade;
    }

    public void setTrade(String trade) {
        Trade = trade;
    }

    public String getMonth() {
        return Month;
    }

    public void setMonth(String month) {
        Month = month;
    }

    public String getYear() {
        return Year;
    }

    public void setYear(String year) {
        Year = year;
    }

    public Date getDate() {
        return Date;
    }

    public void setDate(Date date) {
        Date = date;
    }

    public Double getPrice() {
        return Price;
    }

    public void setPrice(Double price) {
        Price = price;
    }

    public String getExDate() {
        return ExDate;
    }

    public void setExDate(String exDate) {
        ExDate = exDate;
    }

    public Double getExPrice() {
        return ExPrice;
    }

    public void setExPrice(Double exPrice) {
        ExPrice = exPrice;
    }

    public String getPercentageChange() {
        return PercentageChange;
    }

    public void setPercentageChange(String percentageChange) {
        PercentageChange = percentageChange;
    }

    public String getProfit() {
        return Profit;
    }

    public void setProfit(String profit) {
        Profit = profit;
    }

    public String getPercentageProfit() {
        return PercentageProfit;
    }

    public void setPercentageProfit(String percentageProfit) {
        PercentageProfit = percentageProfit;
    }

    public String getShares() {
        return Shares;
    }

    public void setShares(String shares) {
        Shares = shares;
    }

    public String getPositionValue() {
        return PositionValue;
    }

    public void setPositionValue(String positionValue) {
        PositionValue = positionValue;
    }

    public String getCumProfit() {
        return CumProfit;
    }

    public void setCumProfit(String cumProfit) {
        CumProfit = cumProfit;
    }

    public String getNoOfBars() {
        return NoOfBars;
    }

    public void setNoOfBars(String noOfBars) {
        NoOfBars = noOfBars;
    }

    public String getProfitBar() {
        return ProfitBar;
    }

    public void setProfitBar(String profitBar) {
        ProfitBar = profitBar;
    }

    public String getMAE() {
        return MAE;
    }

    public void setMAE(String MAE) {
        this.MAE = MAE;
    }

    public String getMFE() {
        return MFE;
    }

    public void setMFE(String MFE) {
        this.MFE = MFE;
    }

    public String getScaleInOut() {
        return ScaleInOut;
    }

    public void setScaleInOut(String scaleInOut) {
        ScaleInOut = scaleInOut;
    }
}

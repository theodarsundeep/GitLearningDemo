package com.vriddhi.apps.Utils;

import com.opencsv.bean.CsvToBeanFilter;
import com.opencsv.bean.MappingStrategy;

public class TickerDateFilter implements CsvToBeanFilter {

 	private final MappingStrategy strategy;
 	private String strBuySellDate;

 	public TickerDateFilter(MappingStrategy strategy) {
 		this.strategy = strategy;
 	}

 	public boolean allowLine(String[] line) {
 		String value = line[1];
 		boolean result = strBuySellDate.equals(value);
 		return result;
 	}

	public String getStrBuySellDate() {
		return strBuySellDate;
	}

	public void setStrBuySellDate(String strBuySellDate) {
		this.strBuySellDate = strBuySellDate;
	}
}
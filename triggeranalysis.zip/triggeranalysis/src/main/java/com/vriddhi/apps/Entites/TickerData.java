package com.vriddhi.apps.Entites;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvCustomBindByName;
import com.vriddhi.apps.Utils.LocalDateConverter;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;

public class TickerData {
    //Ticker,Date,Time,Open,High,Low,Close,Volume

    @CsvBindByName(column = "Ticker")
    private String Ticker;
    @CsvBindByName(column = "Date")
    private String Date;
    @CsvBindByName(column = "Time")
    private String Time;
    @CsvBindByName(column = "Open")
    private Double Open;
    @CsvBindByName(column = "High")
    private String High;
    @CsvBindByName(column = "Low")
    private String Low;
    @CsvBindByName(column = "Close")
    private String Close;
    @CsvBindByName(column = "Volume")
    private String Volume;

    public String getTicker() {
        return Ticker;
    }

    public void setTicker(String ticker) {
        Ticker = ticker;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public Date getTicketDateTime() throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
        Date parse = formatter.parse(this.Date+" "+this.Time);
        return parse;
    }

    public Double getOpen() {
        return Open;
    }

    public void setOpen(Double open) {
        Open = open;
    }

    public String getHigh() {
        return High;
    }

    public void setHigh(String high) {
        High = high;
    }

    public String getLow() {
        return Low;
    }

    public void setLow(String low) {
        Low = low;
    }

    public String getClose() {
        return Close;
    }

    public void setClose(String close) {
        Close = close;
    }

    public String getVolume() {
        return Volume;
    }

    public void setVolume(String volume) {
        Volume = volume;
    }
}

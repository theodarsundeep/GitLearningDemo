package com.vriddhi.apps.Utils;

import com.opencsv.bean.AbstractBeanField;
import com.opencsv.exceptions.CsvConstraintViolationException;
import com.opencsv.exceptions.CsvDataTypeMismatchException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class LocalDateConverter extends AbstractBeanField {
    @Override
    protected Object convert(String s) throws CsvDataTypeMismatchException, CsvConstraintViolationException {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy HH:mm");
            Date parse = formatter.parse(s);
            //return Instant.ofEpochMilli(parse.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
            return parse;
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
}
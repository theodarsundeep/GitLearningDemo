package com.vriddhi.apps.Entites;

public class TriggerResult {

    private String Symbol;
    private String Trade;
    private String Month;
    private String Year;
    private java.util.Date Date;
    private Double Price;
    private Double OpenPrice;
    private java.util.Date OccurrenceDate;
    private Long OccurrenceMins;

    public TriggerResult() {

    }

    public TriggerResult(String symbol, String trade, String month, String year, java.util.Date date, Double price, Double openPrice, java.util.Date occurrenceDate, Long occuranceMins) {
        Symbol = symbol;
        Trade = trade;
        Month = month;
        Year = year;
        Date = date;
        Price = price;
        OpenPrice = openPrice;
        OccurrenceDate = occurrenceDate;

        //Duration objDur = Duration.between(Date.toInstant(), OccuranceDate.toInstant());
        OccurrenceMins = occuranceMins;
    }

    public String getSymbol() {
        return Symbol;
    }

    public void setSymbol(String symbol) {
        Symbol = symbol;
    }

    public String getTrade() {
        return Trade;
    }

    public void setTrade(String trade) {
        Trade = trade;
    }

    public String getMonth() {
        return Month;
    }

    public void setMonth(String month) {
        Month = month;
    }

    public String getYear() {
        return Year;
    }

    public void setYear(String year) {
        Year = year;
    }

    public java.util.Date getDate() {
        return Date;
    }

    public void setDate(java.util.Date date) {
        Date = date;
    }

    public Double getPrice() {
        return Price;
    }

    public void setPrice(Double price) {
        Price = price;
    }

    public Double getOpenPrice() {
        return OpenPrice;
    }

    public void setOpenPrice(Double openPrice) {
        OpenPrice = openPrice;
    }

    public java.util.Date getOccurrenceDate() {
        return OccurrenceDate;
    }

    public void setOccurrenceDate(java.util.Date occurrenceDate) {
        OccurrenceDate = occurrenceDate;
    }

    public Long getOccurrenceMins() {
        return OccurrenceMins;
    }
}

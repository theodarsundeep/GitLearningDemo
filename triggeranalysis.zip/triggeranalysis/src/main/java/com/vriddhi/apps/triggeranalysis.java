package com.vriddhi.apps;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.bean.*;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;
import com.vriddhi.apps.Entites.BuySellCalls;
import com.vriddhi.apps.Entites.TickerData;
import com.vriddhi.apps.Entites.TriggerResult;
import com.vriddhi.apps.Utils.TickerDateFilter;
import org.jetbrains.annotations.NotNull;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Hello world!
 *
 */
public class triggeranalysis {
    public static void main(@org.jetbrains.annotations.NotNull String[] args) {
        try {

            if(args.length == 0)
            {
                System.out.println("Pass Parameters: <PathToBuySellCSV> <PathTo1MinDataCSV> <PathToResultsFolder> <MaxMinutes>");
            }

            if (args.length == 4) {
                String strBuySellPath = args[0];
                String strTickerDataPath = args[1];
                String strOutputPath = args[2];
                Integer iMaxMins = Integer.parseInt(args[3]);

                System.out.println("Buy Sell CSV Path : " + strBuySellPath);
                System.out.println("Ticker Data CSV Path : " + strTickerDataPath);
                System.out.println("**** Analysis Started *** ");
                Instant analysisStart = Instant.now();

                List<TriggerResult> lstTriggerResult = getTriggerResults(strBuySellPath, strTickerDataPath, iMaxMins);

                WriteResults(strOutputPath, lstTriggerResult);

                Instant analysisEnd = Instant.now();
                System.out.println("**** Analysis Completed *** ");
                System.out.println("Time Taken --> " +Duration.between(analysisStart, analysisEnd).toMinutes()+ " Mins");
                System.out.println(" Results --> " + strOutputPath);

                Map<Long, List<TriggerResult>> groupedByMins = lstTriggerResult.stream()
                        .collect(Collectors.groupingBy( (obj -> (obj.getOccurrenceMins()))));

                groupedByMins.entrySet()
                        .forEach(e -> System.out.println(e.getKey() + " Mins -> " + e.getValue().size()));
            } else {
                System.out.println("Invalid number of arguments! Try Again.");
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (CsvRequiredFieldEmptyException e) {
            e.printStackTrace();
        } catch (CsvDataTypeMismatchException e) {
            e.printStackTrace();
        }
    }

    @NotNull
    private static List<TriggerResult> getTriggerResults(String strBuySellPath, String strTickerDataPath, Integer iMaxMins) throws FileNotFoundException {
        HeaderColumnNameMappingStrategy straBuySellCSV = new HeaderColumnNameMappingStrategy();
        straBuySellCSV.setType(BuySellCalls.class);

        CsvToBean<BuySellCalls> ctbBuySellCall = new CsvToBean<>();
        ctbBuySellCall.setCsvReader(new CSVReader(new FileReader(strBuySellPath)));
        ctbBuySellCall.setMappingStrategy(straBuySellCSV);

        List<BuySellCalls> lstBuySellCalls = ctbBuySellCall.parse();
        List<TriggerResult> lstTriggerResult = new ArrayList<>();

        for (BuySellCalls objBuySell : lstBuySellCalls) {
            List<TickerData> lstTickerData = new ArrayList<>();
            DateFormat df = new SimpleDateFormat("dd/MM/yy");
            String strBuySellDate = df.format(objBuySell.getDate());
            objBuySell.getPrice();

            AnalyseTickerData(strTickerDataPath, iMaxMins, lstTriggerResult, objBuySell, lstTickerData, strBuySellDate);
        }
        return lstTriggerResult;
    }

    private static void WriteResults(String strOutputPath, List<TriggerResult> lstTriggerResult) throws IOException, CsvDataTypeMismatchException, CsvRequiredFieldEmptyException {
        strOutputPath = strOutputPath+"Results_Run"+ Instant.now().getEpochSecond() +".csv";
        Writer writer = Files.newBufferedWriter(Paths.get(strOutputPath));
        ColumnPositionMappingStrategy mappingStrategy = new ColumnPositionMappingStrategy();
        mappingStrategy.setType(TriggerResult.class);

        String[] columns = new String[] { "Symbol", "Trade", "Month", "Year", "Date", "Price", "OpenPrice", "OccurrenceDate", "OccurrenceMins" };
        mappingStrategy.setColumnMapping(columns);

        StatefulBeanToCsvBuilder<TriggerResult> builder= new StatefulBeanToCsvBuilder(writer);

        StatefulBeanToCsv beanWriter = builder.withMappingStrategy(mappingStrategy)
                .build();
        beanWriter.write(lstTriggerResult);

        writer.close();
    }

    private static void AnalyseTickerData(String strTickerDataPath, Integer iMaxMins, List<TriggerResult> lstTriggerResult, BuySellCalls objBuySell, List<TickerData> lstTickerData, String strBuySellDate) {
        try (Stream<String> stream = Files.lines(Paths.get(strTickerDataPath))) {

            List<String> list = stream.filter(line -> line.contains(strBuySellDate)).collect(Collectors.toList());
            for (String line : list) {
                String[] arrLine = line.split(",");
                Double openPrice = Double.parseDouble(arrLine[3]);
                Double highPrice = Double.parseDouble(arrLine[4]);
                Double lowPrice = Double.parseDouble(arrLine[5]);

                TickerData objTickerData = new TickerData();
                objTickerData.setTicker(arrLine[0]);
                objTickerData.setDate(arrLine[1]);
                objTickerData.setTime(arrLine[2]);
                objTickerData.setOpen(openPrice);
                objTickerData.setHigh(arrLine[4]);
                objTickerData.setLow(arrLine[5]);
                objTickerData.setClose(arrLine[6]);
                objTickerData.setVolume(arrLine[7]);
                lstTickerData.add(objTickerData);

                switch (objBuySell.getTrade()) {
                    case "Long":
                        if ( objTickerData.getTicketDateTime().after(objBuySell.getDate()) &&
                                ((highPrice >= objBuySell.getPrice() && highPrice <= (objBuySell.getPrice() + 3)) ||
                                (lowPrice >= objBuySell.getPrice() && lowPrice <= (objBuySell.getPrice() + 3)))
                        ){

                            AddTriggerResult(iMaxMins, lstTriggerResult, objBuySell, objTickerData);
                        }
                        break;
                    case "Short":
                        if ( objTickerData.getTicketDateTime().after(objBuySell.getDate()) &&
                                ((highPrice <= objBuySell.getPrice() && highPrice >= (objBuySell.getPrice() - 3)) ||
                                (lowPrice <= objBuySell.getPrice() && lowPrice >= (objBuySell.getPrice() - 3)))
                        ){
                            AddTriggerResult(iMaxMins, lstTriggerResult, objBuySell, objTickerData);
                        }
                        break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private static void AddTriggerResult(Integer iMaxMins, List<TriggerResult> lstTriggerResult, BuySellCalls objBuySell, TickerData objTickerData) throws ParseException {

        Date OccurrenceDate = objTickerData.getTicketDateTime();
        Duration objDur = Duration.between(objBuySell.getDate().toInstant(), OccurrenceDate.toInstant());
        Long OccurrenceMins = objDur.toMinutes();
        if (OccurrenceMins <= iMaxMins) {
            TriggerResult objTriggerRes = new TriggerResult(objBuySell.getSymbol(), objBuySell.getTrade(), objBuySell.getMonth(), objBuySell.getYear(), objBuySell.getDate(), objBuySell.getPrice(), objTickerData.getOpen(), OccurrenceDate, OccurrenceMins);
            lstTriggerResult.add(objTriggerRes);
        }

    }
}
